<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Student;


class WebController extends Controller
{
    //

    public function welcome(){
    
        return view('welcome');
    }
    
    public function data(){
        $data=[
            ["id"=>1,"Name"=>"Bankat","Email"=>"Fifthson@gmail.com","Gender"=>"Male"],
            ["id"=>2,"Name"=>"Doe","Email"=>"JoeDoe@gmail.com","Gender"=>"Male"],
            ["id"=>3,"Name"=>"Sarah","Email"=>"Sarah@gmail.com","Gender"=>"Female"],
            ["id"=>4,"Name"=>"Esther","Email"=>"Esther@yandex.com","Gender"=>"Female"],
            ["id"=>5,"Name"=>"Henry","Email"=>"Henry@yahoo.com","Gender"=>"Male"]
        ];

    return view("class",compact('data'));
    }

    public function index(){
        // $students=Student::all();
        //Order Record by using paginate
        $students=Student::orderBy('id','Desc')->paginate(10);



        return view('index',['student'=>$students]);
    }
    public function create(){
        return view('create');

    }

    public function edit($id){
        $student=Student::find($id);

        return view('edit',['student'=>$student]);
        
    }
    public function store(Request $request){
        
        $form_data=$request->validate(
            [
                'firstname'=>'required',
                'lastname'=>'required',
                'email'=>'required|unique:students',
                'phone'=>'required|min:11|numeric',
                'address'=>'required'
            ]
           

        );
        // dd($form_data);
        $student=new Student();
        $student->firstname=$request->firstname;
        $student->lastname=$request->lastname;
        $student->phone=$request->phone;
        $student->email=$request->email;
        $student->address=$request->address;

        $student->save();



        return redirect('index');
        
    }
    public function update(Request $request,$id){
        $student_info=Student::find($id);
        $student_info->firstname=$request->firstname;
        $student_info->lastname=$request->lastname;
        $student_info->phone=$request->phone;
        $student_info->email=$request->email;
        $student_info->address=$request->address;

        $student_info->save();
        return redirect('index');
    }

    

        public function delete($id){

            $delete_student=Student::find($id);

            $delete_student->delete();

            return redirect('index');


        }


    
}
